/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_lib.h"
#include "KeyForSTM32.h"
#include "LCD_DIS.h"
#include "LCD_Config.h"
#include "Menu_GUI.h"
#include "DeviceConfig.h"
#include "UserTask.h"
#include "main.h"

/* Private function prototypes -----------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : XXXXXXXXXXXXXXX
* Description    : XXXXXXXXXXXXXX
* Input          : None
* Output         : None
* Return         : None
******************************************************************************
void XXXX(void)
{
}
*/
