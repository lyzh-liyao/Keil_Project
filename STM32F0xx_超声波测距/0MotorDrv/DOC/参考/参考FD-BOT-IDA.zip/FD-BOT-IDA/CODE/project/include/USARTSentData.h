#ifndef USARTSentData_H
#define USARTSentData_H

extern void UpLoadState(void);
extern void UsartSentDataBuf(void);
extern void Uart1WriteBuf(u16 *p, u16 num);
extern void Uart2WriteBuf(u16 *p, u16 num);

#endif  

