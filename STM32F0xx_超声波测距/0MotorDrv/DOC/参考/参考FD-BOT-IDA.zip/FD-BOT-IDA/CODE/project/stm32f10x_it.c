/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "main.h"
#include "DeviceConfig.h"
#include "USARTCMD.h"   
#include "motorDriver.h"
#include "TaskEXE.h"

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	u16 temp;
	TASK_PARM *taskTemp;
//	TimeToChangeSour();
	time5ms++;
	
	if(tasks.pauseFlag != 1)//���������ͣ��״̬��������ʱ����������
	{
		for(temp = 0; temp < TASK_NUM; temp++)
		{
			taskTemp = &tasks.MotorReset + temp;
			if(taskTemp->delay1)taskTemp->delay1--;
			if(taskTemp->delay2)taskTemp->delay2--;
			if(taskTemp->delay3)taskTemp->delay3--;
		}
	}
	if(timeToHoldSteering)		//�������ոն��������������
	{
		timeToHoldSteering--;
		if(timeToHoldSteering == 0)SetSteeringHold();
	}
	
	if(time5ms >= 400)
	{
		time5ms = 0;
	}
	if(time5ms == 0)
	{
		LED1_ON;
		LED2_OFF;
	}
	if(time5ms == 100)
	{
		LED1_OFF;
		LED2_ON;
	}
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */

/*******************************************************************************
* Function Name  : DMA1_Channel1_IRQHandler
* Description    : This function handles DMA1 Channel 1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel1_IRQHandler(void)
{
	if(DMA_GetITStatus(DMA1_IT_TC1) != RESET)
	{
		DMA_ClearITPendingBit(DMA1_IT_TC1);
		ADC_SoftwareStartConvCmd(ADC1, DISABLE);
		ADC_readyFlag = 1;
	}
}

/*******************************************************************************
* Function Name  : USART1_IRQHandler
* Description    : This function handles USART1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USART1_IRQHandler(void)
{
	static u16 uartRecCon = 0;
	static u16 rxBuffer[USART_CMD_RXBUR_NUM+1];
	static u16 change0xFEFlag = 0; 
	static u16 sum = 0;
	vu16 CharRcv;
	u16 temp;
	u16 *p;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)	//
	{
		USART_ClearFlag(USART1,USART_FLAG_RXNE);
		CharRcv = USART_ReceiveData(USART1);

		if(CharRcv == 0xfd)uartRecCon = change0xFEFlag = sum = 0;
		else if(uartRecCon != 0xff)
		{
			if(CharRcv == 0xfe)change0xFEFlag = 1;
			else
			{
				if(change0xFEFlag)
				{
					change0xFEFlag = 0;
					if(CharRcv == 0x7d)CharRcv = 0xfd;
					else if(CharRcv == 0x7e)CharRcv = 0xfe;
					else if(CharRcv == 0x78)CharRcv = 0xf8;
					else;
				}
				else if(CharRcv == 0xf8)//�������
				{
					if(uartRecCon < 2)//��λ���������ݳ�֡ͷ֡β��������5������,������һָ֡��û�д�����
					{
						uartRecCon = 0xff;
						return;	
					}	
					uartRecCon--;
					sum -= rxBuffer[uartRecCon];	//��ȥ���һ�����ϵ�У���
					sum = sum & 0x00ff;
					if(1)		//У�����ȷ sum == rxBuffer[uartRecCon]
					{
						p = usartCMDRxBuf.usartCMDRxBuf0 + usartCMDRxBuf.usartCMDBufCon * USART_CMD_RXBUR_NUM;//  
						for(temp = 0; temp < uartRecCon; temp++)
						{
							p[temp] = rxBuffer[temp];
						}
						if(++usartCMDRxBuf.usartCMDBufCon == 5)usartCMDRxBuf.usartCMDBufCon = 0;
					}
					uartRecCon = 0xff;
					return;
				}
				rxBuffer[uartRecCon] = CharRcv;
				uartRecCon++;
				sum += CharRcv;
				if(uartRecCon > USART_CMD_RXBUR_NUM+1)
				{
					uartRecCon = 0xff;
					return;
				}
			}
		}
	}
}


/*******************************************************************************
* Function Name  : USART2_IRQHandler
* Description    : This function handles USART2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
	{
		USART_ClearFlag(USART2 ,USART_FLAG_RXNE);		//??????
//		RxBuffer2 = USART_ReceiveData(USART2) ;
	}
}

/*******************************************************************************
* Function Name  : USART3_IRQHandler
* Description    : This function handles USART3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USART3_IRQHandler(void)
{
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{
		USART_ClearFlag(USART3 ,USART_FLAG_RXNE);		//??????
//		RxBuffer3 = USART_ReceiveData(USART3) ;
	}
}
/*******************************************************************************
* Function Name  : UART4_IRQHandler
* Description    : This function handles UART4 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UART4_IRQHandler(void)
{
	if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
	{
		USART_ClearFlag(UART4 ,USART_FLAG_RXNE);		//??????
// 		RxBuffer4 = USART_ReceiveData(UART4) ;
	} 
}

/*******************************************************************************
* Function Name  : UART5_IRQHandler
* Description    : This function handles UART5 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UART5_IRQHandler(void)
{
	if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)	//
	{
		USART_ClearFlag(UART5 ,USART_FLAG_RXNE);
	}
}

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
