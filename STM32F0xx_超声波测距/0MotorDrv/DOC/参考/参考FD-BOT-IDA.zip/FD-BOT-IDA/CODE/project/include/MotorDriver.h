#ifndef MOTORDRIVER_H
#define MOTORDRIVER_H

extern u16 timeToHoldSteering;
extern MOTORS Motors;
extern void MotorInt(void);
extern void SetMotorSpeed(u32 motorID, u16 speed, s16 dir);
extern void StartPWM(void);
extern void SetMotorBrake(u32 MotorID);
extern void SetSteering(u16 pwm);
extern void SetSteeringHold(void);
extern void MotorBrakeUnlock(void);
extern void SetMotorENA(u32 motorID, u16 enableFlag);//������ػ����ͷ�
extern void ReadMotorLocation(u32 motorID);
extern void SetMotorLocation(u32 MotorID, s32 location);
extern void SetMotorLocationZero(u32 motorID);
extern void ReadMotorNowCurrent(u32 motorID);
extern void SaveToDrvEEPROM(u32 motorID);


#endif  
