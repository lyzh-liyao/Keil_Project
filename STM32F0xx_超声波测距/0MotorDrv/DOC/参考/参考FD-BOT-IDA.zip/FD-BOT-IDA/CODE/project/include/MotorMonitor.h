#ifndef MOTORMONITOR_H
#define MOTORMONITOR_H


extern void MotorMonitor(void);
extern void MotorMonitorInit(void);


#endif  

