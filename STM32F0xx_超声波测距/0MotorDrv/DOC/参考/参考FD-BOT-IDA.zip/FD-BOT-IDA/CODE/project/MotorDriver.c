//###########################################################################
//
// FILE:    MotorDrive.c
//
// TITLE:   �����������������
//
// ASSUMPTIONS:
//
//
// DESCRIPTION:
//         
//
//###########################################################################
#include "stm32f10x.h"
#include "main.h"
#include "DeviceConfig.h"
#include "USARTSentData.h"

MOTORS Motors;
u16 timeToHoldSteering = 0;		//�����ö���󣬹����趨ʱ��ر�PWM��ʱ����������������

void MotorInt(void);
void SetMotorSpeed(u32 motorID, u16 speed, s16 dir);
void StartPWM(void);
void SetMotorBrake(u32 MotorID);
void SetSteering(u16 pwm);
void SetSteeringHold(void);
void MotorBrakeUnlock(void);
void SetMotorENA(u32 motorID, u16 enableFlag);//������ػ����ͷ�
void ReadMotorLocation(u32 motorID);
void SetMotorLocation(u32 MotorID, s32 location);
void SetMotorLocationZero(u32 motorID);
void ReadMotorNowCurrent(u32 motorID);
void SaveToDrvEEPROM(u32 motorID);


void MotorInt(void)	// ��ʼ���������
{
	u16 temp;
	MOTOR_PARM *motorTemp;
	u16 motorDrvTypSet[7] = {MOTOR_DRVTYP1, MOTOR_DRVTYP2, MOTOR_DRVTYP3, MOTOR_DRVTYP4, MOTOR_DRVTYP5, MOTOR_DRVTYP6, MOTOR_DRVTYP7};

	for(temp = 0; temp < MOTOR_NUM; temp++)
	{
		motorTemp = &Motors.motor1 + temp;
		motorTemp->motorID = temp + 1;
		motorTemp->motorDrvTyp = motorDrvTypSet[temp];
		motorTemp->motorDirLock = 0;
		motorTemp->motorDir = 0;
		motorTemp->motorSpeed = 0;
		motorTemp->locationReqFlag = 0;
		motorTemp->locationUpdateFlag = 0;
		motorTemp->location = 0xffff;	
		motorTemp->nowCurrentReqFlag = 0;
		motorTemp->nowCurrentUpdateFlag = 0;
		motorTemp->nowCurrent = 0xffff;	
		motorTemp->manualUpdate = 0;
		motorTemp->brakeUnlockDelayFlag = 0;
		motorTemp->motorEnaFlag = 1;		
	}
	SET_MOTOR_BRAKE_L;							//���ϱ�բ
	SET_MOTOR_BRAKE_R;

}

void SetMotorSpeed(u32 motorID, u16 speed, s16 dir)//�ٶ�ֵ0-100
{
	u16 n = 0;
	MOTOR_PARM *motorTemp;
	u16 motorCMD[10] = {' ',' ',' ',' ',' ',' ',' ',' ',' ',' '};	//�ո��Ǳ����Եģ�ֻ������MC�����ʱ���ʹ��
	
	if(speed == 0){SetMotorBrake(motorID);return;}
	
	motorTemp = &Motors.motor1 + motorID - 1;
	if(		(motorTemp->motorDirLock == dir)		//����������ס���򲻷���ָ��
		||	(motorTemp->brakeUnlockDelayFlag)		//��û����
		||	(motorTemp->motorDir == (dir * (-1))))	//���ڷ�����תҲ���У����׵������
	{
		msgToUpload = MSG_MOTOR_NOT_READY;	//���δ׼����
		return; 	
	}
	if(dir == 0 || speed >= 100)			//������ȷ	//�ٶȲ��ܴ���100
	{
		msgToUpload = MSG_PARAM_ERR;		//��������
		return; 	
	}

	if(motorTemp->motorDrvTyp == MOTOR_DRVTYP_SC)
	{
		if(motorTemp->motorPreSpeed != speed)
		{
			if(motorID == ID_MOTOR_L)
			{
				if(dir == DIR_MOTOR_CLK)SET_MOTOR_L_CLK;
				else SET_MOTOR_L_UCLK;
				motorTemp->motorPreSpeed = speed;
				motorTemp->setDirDelay = 4;
			}
			else if(motorID == ID_MOTOR_R)
			{
				if(dir == DIR_MOTOR_CLK)SET_MOTOR_R_CLK;
				else SET_MOTOR_R_UCLK;
				motorTemp->motorPreSpeed = speed;
				motorTemp->setDirDelay = 4;
			}
		}
	}
	else if(motorTemp->motorDrvTyp == MOTOR_DRVTYP_MC)
	{
		speed = speed * 40;				//���4000ת
		SetMotorENA(motorID, 1);		//���ص�����˺����л����жϣ����Ѿ���������ԡ�
		motorCMD[n++] = motorID + 48;		//תASCII��
		motorCMD[n++] = 'V';
		if(dir == -1)motorCMD[n++] = '-';	//�����������������ΪԤ��Ŀո񣬿�����������Կո񣬸�����Ҫ��ȥ�ո���

		if(speed > 999)
		{
			motorCMD[n+3] = (speed % 10) + 48;	
			speed /= 10;
			motorCMD[n+2] = (speed % 10) + 48;
			speed /= 10;
			motorCMD[n+1] = (speed % 10) + 48;
			speed /= 10;
			motorCMD[n] = (speed % 10) + 48;
			n = n + 4;
		}
		else if(speed > 99)
		{
			motorCMD[n+2] = (speed % 10) + 48;
			speed /= 10;
			motorCMD[n+1] = (speed % 10) + 48;
			speed /= 10;
			motorCMD[n] = (speed % 10) + 48;
			n = n + 3;
		}
		else if(speed > 9)
		{
			motorCMD[n+1] = (speed % 10) + 48;
			speed /= 10;
			motorCMD[n] = (speed % 10) + 48;
			n = n + 2;
		}
		else motorCMD[n++] = speed + 48;

		motorCMD[n++] = 13;	//�س�	CR
		Uart2WriteBuf(motorCMD, n);
	}
	else ;
	
	motorTemp->motorDir = dir;
}

void SetMotorBrake(u32 motorID)
{
	MOTOR_PARM *motorTemp;
	u16 motorCMD[4] = {' ','V','0',13};	//�ո��Ǳ����Ե�
	
	motorTemp = &Motors.motor1 + motorID - 1;
	
//	if(motorTemp->motorSpeed == 0)return; 					//�ٶ��Ѿ���0

	if(motorTemp->motorDrvTyp == MOTOR_DRVTYP_SC)
	{
		if(motorID == ID_MOTOR_L)
		{
			TIM_SetCompare3(TIM3, 0);
			SET_MOTOR_BRAKE_L;
//			LED1_OFF;
		}
		else if(motorID == ID_MOTOR_R)
		{
			TIM_SetCompare4(TIM3, 0);
			SET_MOTOR_BRAKE_R;
//			LED2_OFF;
		}
	}
	else if(motorTemp->motorDrvTyp == MOTOR_DRVTYP_MC)
	{
		motorCMD[0] = motorID + 48;				//תASCII��
		Uart2WriteBuf(motorCMD, 4);
	}
	else ;

	
	motorTemp->motorDir = 0;
	motorTemp->motorSpeed = 0;
	motorTemp->motorPreSpeed = 0;
	motorTemp->setDirDelay = 0;
//	motorTemp->brakeUnlockDelayFlag = 60;		//ɲ����һ��ʱ�䲻��������0.3s
}

void SetSteering(u16 pwm)
{
	TIM_Cmd(TIM4, ENABLE);
	TIM_SetCompare3(TIM4, pwm);	
	timeToHoldSteering = MOTOR_TESTMOTOR_DELAY;		//�ڶ�ʱ���л�5ms��һ�Σ���������SetSteeringHold(void)
	testPos = pwm;
}

void SetSteeringHold(void)
{
	TIM_Cmd(TIM4, DISABLE);
}

void MotorBrakeUnlock(void)
{
	u16 temp;
	MOTOR_PARM *motorTemp;
	for(temp = 0; temp < MOTOR_NUM; temp++)
	{
		motorTemp = &Motors.motor1 + temp;
		if(motorTemp->brakeUnlockDelayFlag)
		{
			motorTemp->brakeUnlockDelayFlag--;
		}
	}
}
void StartPWM(void)
{
	u16 temp;
	MOTOR_PARM *motorTemp;
	for(temp = 0; temp < MOTOR_NUM; temp++)
	{
		motorTemp = &Motors.motor1 + temp;
		if(motorTemp->setDirDelay)
		{
			motorTemp->setDirDelay--;
			if(motorTemp->setDirDelay == 0)
			{
				if(motorTemp->motorID == ID_MOTOR_L)
				{
					SET_MOTOR_UNBRAKE_L;
					TIM_SetCompare3(TIM3, motorTemp->motorPreSpeed);
//					LED1_ON;
				}
				else if(motorTemp->motorID == ID_MOTOR_R)
				{
					SET_MOTOR_UNBRAKE_R;
					TIM_SetCompare4(TIM3, motorTemp->motorPreSpeed);
//					LED2_ON;
				}
				motorTemp->motorSpeed = motorTemp->motorPreSpeed;
				motorTemp->motorPreSpeed = 0;
			}
		}
	}
}

void SetMotorENA(u32 motorID, u16 enableFlag)//������ػ����ͷ�  1:���� 0:�ͷ�
{
	MOTOR_PARM *motorTemp;
	u16 motorENCMD[4] = {' ','E','N',13};	
	u16 motorDICMD[4] = {' ','D','I',13};

	motorTemp = &Motors.motor1 + motorID-1;
	if(motorTemp->motorEnaFlag == enableFlag)return;//����Ѿ�ʹ�ܣ�����Ҫ��ʹ��һ��
	motorTemp->motorEnaFlag = enableFlag;
	
	if(enableFlag == 1)
	{
		motorENCMD[0] = motorID + 48;
		Uart2WriteBuf(motorENCMD, 4);
	}
	else
	{
		motorDICMD[0] = motorID + 48;
		Uart2WriteBuf(motorDICMD, 4);
	}
}

void SetMotorLocation(u32 motorID, s32 location)
{
}
void ReadMotorLocation(u32 motorID)
{
}
void SetMotorLocationZero(u32 motorID)
{
}
void ReadMotorNowCurrent(u32 motorID)
{
}
void SaveToDrvEEPROM(u32 motorID)
{
}

