#ifndef USARTCMD_H
#define USARTCMD_H

extern USARTCMDRXBUF usartCMDRxBuf;
extern void DealUsartCMD(void);
extern void UsartCMDRxBufInt(void);








#endif  
