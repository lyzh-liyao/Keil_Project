/******************** (C) COPYRIGHT 2009 Chen Yao ******************************
* File Name          : STM32_DevInit.c
* Author             : Chen Yao
* Version            : V1.0
* Date               : 11/6/2008
* Description        : STM32 Hardware Init
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "main.h"
#include "DeviceConfig.h"

/* Private typedef -----------------------------------------------------------*/
//DMA_InitTypeDef	DMA_InitStructure;
/* Private define ------------------------------------------------------------*/
#define ADC1_DR_Address		((u32)0x4001244C)//ADC���ݵ�ַ����DMA��
#define DAC_DHR12R1			((u32)0x40007408)//DAC���ݵ�ַ����DMA��


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void SysTick_Configuration(void);

#ifdef __STM32F10x_ADC_H
void ADC_Configuration(void);
#endif

#ifdef __STM32F10x_DAC_H
void DAC_Configuration(void);
#endif

#ifdef __STM32F10x_DMA_H
void DMA_Configuration(void);
#endif

#ifdef __STM32F10x_EXTI_H
void EXTI_Configuration(void);
#endif

#ifdef __STM32F10x_GPIO_H
void GPIO_Configuration(void);
#endif

#ifdef __STM32F10x_I2C_H
void I2C_Configuration(void);
#endif

#ifdef __MISC_H
void NVIC_Configuration(void);
#endif

#ifdef __STM32F10x_SPI_H
void SPI_Configuration(void);
#endif

#ifdef __STM32F10x_TIM_H
void TIM_Configuration(void);
#endif

#ifdef __STM32F10x_USART_H
void USART_Configuration(void);
#endif

#ifdef __STM32F10x_WWDG_H
void WDG_Configuration(void);                //���Ź���ʼ��
#endif
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : STM32_DevInit
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void STM32_DevInit(void)
{
	RCC_APB2PeriphClockCmd(   RCC_APB2Periph_GPIOA
							| RCC_APB2Periph_GPIOB
						 	| RCC_APB2Periph_GPIOC
							| RCC_APB2Periph_GPIOD 
							| RCC_APB2Periph_GPIOE
							| RCC_APB2Periph_USART1
//							| RCC_APB2Periph_SPI1
						 	| RCC_APB2Periph_ADC1
							| RCC_APB2Periph_AFIO, ENABLE);

	RCC_APB1PeriphClockCmd(// RCC_APB1Periph_SPI2
//							  RCC_APB1Periph_TIM2
									RCC_APB1Periph_TIM3
								| RCC_APB1Periph_TIM4,	ENABLE);
//							| RCC_APB1Periph_USART2
//							| RCC_APB1Periph_USART3
//							| RCC_APB1Periph_UART4 
//							| RCC_APB1Periph_UART5	
						//	| RCC_APB1Periph_WWDG			 //�򿪿��Ź�
						
// DMA clock enable,DMA1��ͨ��1������ADC1��5�����ݴ���
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	SysTick_Configuration();
	
#ifdef __STM32F10x_DMA_H
	DMA_Configuration();
#endif

#ifdef __STM32F10x_GPIO_H
	GPIO_Configuration();
#endif	

#ifdef __STM32F10x_SPI_H
	SPI_Configuration();
#endif

#ifdef __STM32F10x_USART_H
	USART_Configuration();
#endif

#ifdef __STM32F10x_ADC_H
	ADC_Configuration();
#endif

#ifdef __STM32F10x_EXTI_H
	EXTI_Configuration();
#endif

#ifdef __MISC_H
	NVIC_Configuration();
#endif

#ifdef __STM32F10x_TIM_H
	TIM_Configuration();
#endif

#ifdef __STM32F10x_WWDG_H
	 WDG_Configuration();                //���Ź���ʼ��
#endif

}

/*******************************************************************************
* Function Name  : ADC_Configuration
* Description    : Configure the ADC
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_ADC_H
void ADC_Configuration(void)
{
	ADC_InitTypeDef ADC_InitStructure;
	/* ADC1 configuration ------------------------------------------------------*/
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;;			//ɨ��
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;		//����
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 3;
	ADC_Init(ADC1, &ADC_InitStructure);
	/* ADC1 regular channels configuration */ 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_239Cycles5); 	// ��ص�ѹ 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 2, ADC_SampleTime_239Cycles5); 	// ��߷���
	ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 3, ADC_SampleTime_239Cycles5); 	// �ұ߷��� 

//	ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);	
	/* Enable ADC1 */
	ADC_Cmd(ADC1, ENABLE);
	/* Enable ADC1 DMA */
	ADC_DMACmd(ADC1, ENABLE);	
	/* Enable ADC1 reset calibaration register */   
	ADC_ResetCalibration(ADC1);
	/* Check the end of ADC1 reset calibration register */
	while(ADC_GetResetCalibrationStatus(ADC1));	
	/* Start ADC1 calibaration */
	ADC_StartCalibration(ADC1);
	/* Check the end of ADC1 calibration */
	while(ADC_GetCalibrationStatus(ADC1));
	ADC_ITConfig(ADC1, ADC_IT_EOC , DISABLE);
	//ʹ�ܻ���ʧ��ADCx�ľ��ⲿ��������ת������ 
//	ADC_ExternalTrigConvCmd(ADC1, ENABLE); 
	// Start ADC1 Software Conversion  
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);

}
#endif


/*******************************************************************************
* Function Name  : DAC_Configuration
* Description    : Configures the DAC
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_DAC_H
void DAC_Configuration(void)
{
	DAC_InitTypeDef  DAC_InitStructure;
  	/* DAC channel1 Configuration*/
  	DAC_InitStructure.DAC_Trigger = DAC_Trigger_T2_TRGO;//DAC_Trigger_None;//
  	DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
  	DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
  	DAC_Init(DAC_Channel_1, &DAC_InitStructure);

  	/* Enable DAC Channel1: Once the DAC channel1 is enabled, PA.04 is 
     	automatically connected to the DAC converter. */
  	DAC_Cmd(DAC_Channel_1, ENABLE);
	DAC_SetDualChannelData(DAC_Align_12b_R, 0x01, 0x01);  
}
#endif

/*******************************************************************************
* Function Name  : DMA_Configuration
* Description    : Configures the used DMA Channel.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_DMA_H
void DMA_Configuration(void)
{
	 /* DMA1 channel1 configuration ----------------------------------------------*/
	DMA_InitTypeDef DMA_InitStructure;
	//�趨DMA1����2*NPT�������㵽�ڴ滺����nADBuffer[2*NPT]
	/* DMA1 Channel1 Configuration ----------------------------------------------*/
	DMA_DeInit(DMA1_Channel1);
	DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)ADC_valueBuf; 			//����������
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;					//������Ϊ������Դ
	DMA_InitStructure.DMA_BufferSize = 60;   
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;	//�����ַ������
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;				//�ڴ��ַ����
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);
	/* Enable DMA1 channel1 */
	DMA_Cmd(DMA1_Channel1, ENABLE);
	DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);		//DMA��������봫������ж�ʹ��
	
	//�趨DMA2����2*NPT���������������ڴ滺����DABuffer[2*NPT]��DAͨ��2
	/* DMA2 Channel 4 Configuration ----------------------------------------------
	DMA_DeInit(DMA2_Channel3);
	DMA_InitStructure.DMA_PeripheralBaseAddr = DAC_DHR12R1;//DAC2_DR_Address;//
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)DAC_buffer;//ADC_buffer; //������ݻ�����
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = 2 * 3496;   //  ��FFT ����
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel3, &DMA_InitStructure);
	// Enable DMA2 channel4 
	DMA_Cmd(DMA2_Channel3, ENABLE);	*/									 								 //����һAD����Ǯ���ݴ������DA��DMA
}
#endif

/*******************************************************************************
* Function Name  : EXTI_Configuration
* Description    : Configure the EXTI
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_EXTI_H
void EXTI_Configuration(void)
{	
	EXTI_InitTypeDef EXTI_InitStructure;
	/* Connect (keyBoard_Key Button EXTI Line to keyBoard_Key Button) GPIO Pin */
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
														
	/* Configure keyBoard_Key Button EXTI Line to generate an interrupt on falling edge */  
	EXTI_InitStructure.EXTI_Line = EXTI_Line0;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	/* Generate software interrupt: simulate a falling edge applied on keyBoard_Key Button EXTI line */
	EXTI_GenerateSWInterrupt(EXTI_Line0);
}
#endif


/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the different GPIO ports.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	
// 2��������LED  PD.09-PD.10
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

// ���⴫����IO
   //PB
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//PD
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOD, &GPIO_InitStructure);	
	
// ���Ƽ��ģ��IO
   //PA9-12
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
// ���PWM��DIR��brake
	//PWM USE PB0-1 TIMER3 CH3 CH4 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	//DIR USE PC4-5
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);	

	//brake USE PE7-8 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);	

	//��� PWM USE PB8 TIMER4 CH3 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
// UART����
/*	//UART5 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;	��TIM3_ETR�г�ͻ��tim3�����ڵ����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
*/
//UART1 FOR COMMUNICATION   PB6 PB7
	GPIO_PinRemapConfig(GPIO_Remap_USART1 , ENABLE);			//USART1 ��ӳ��

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
/*	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
*/	

//��أ���ת�����������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the different I2C .
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_I2C_H
void I2C_Configuration(void)
{
	I2C_InitTypeDef  I2C_InitStructure;
	  /* Enable I2C1 and I2C2 ----------------------------------------------------*/
  	I2C_Cmd(I2C1, ENABLE);
	/* I2C1 configuration ------------------------------------------------------*/
	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;										//ΪI2Cģʽ
	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;					    		//���� I2C ��ռ�ձ�Ϊ50%
	I2C_InitStructure.I2C_OwnAddress1 = I2C1_SLAVE_ADDRESS7;			    		//���õ�һ���豸������ַ
	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;										//ʹ��Ӧ��
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;		//Ӧ�� 7 λ��ַ
	I2C_InitStructure.I2C_ClockSpeed = ClockSpeed;									//����ʱ��Ƶ�ʣ����ֵ���ܸ��� 400KHz��
	I2C_Init(I2C1, &I2C_InitStructure);
	I2C_Cmd(I2C1, ENABLE);
}
#endif

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configure the nested vectored interrupt controller.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __MISC_H
void NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
  
#ifdef  VECT_TAB_RAM  
	// Set the Vector Table base location at 0x20000000
	NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
#else  // VECT_TAB_FLASH
	// Set the Vector Table base location at 0x08000000
	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
#endif

	// Configure one bit for preemption priority
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	 		//��ռ���ȼ�2λ�������ȼ�2λ

	/* Enable the DMA1 Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);

  	/* Enable the USART3 Interrupt */
 	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);

	// Configure and enable TIM3 interrupt  
//	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure);	

}
#endif

/*******************************************************************************
* Function Name  : SPI_Configuration
* Description    : Configures SPI
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_SPI_H
void SPI_Configuration(void)
{
	SPI_InitTypeDef SPI_InitStructure;
	// SPI1 configuration FOR LCD------------------------------------------------------
	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;//ֻ�з�����
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;       //������ʱ�����壬���иߵ�ƽ
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;      //��2�����ز���
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_64;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
//	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI2, &SPI_InitStructure);

	SPI_Cmd(SPI2, ENABLE);
}
#endif

/*******************************************************************************
* Function Name  : SysTick_Configuration
* Description    : Configure the SysTick 5msһ���ж�
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SysTick_Configuration(void)
{
  if (SysTick_Config(SystemCoreClock / 200))
  { 
    /* Capture error */ 
    while (1);
  }
}

/*******************************************************************************
* Function Name  : TIM_Configuration
* Description    : Configure the TIM
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_TIM_H
void TIM_Configuration(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	
//ͨ�ö�ʱ������==============================================================
	// Time Base configuration  
//	TIM_TimeBaseStructure.TIM_Prescaler = 36;		// 1M
//	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
///	TIM_TimeBaseStructure.TIM_Period = 5000;		// 5ms
//	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
//	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
//	TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 
//	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
//	TIM_Cmd(TIM2, ENABLE);   


// PWMģʽ===========================================================================
// Time base configuration
	//TIM3 channel3&4 configuration in PWM mode 
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure); 
  	TIM_TimeBaseStructure.TIM_Prescaler = 720;	//10usһ����λ
  	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
  	TIM_TimeBaseStructure.TIM_Period = 100;		// 1kƵ��
  	TIM_TimeBaseStructure.TIM_ClockDivision = 0;    
  	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);	
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);	
	TIM_ARRPreloadConfig(TIM3, ENABLE);	
	TIM_Cmd(TIM3, ENABLE);
	
	//TIM4 channel3 configuration in PWM mode 
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure); 
  	TIM_TimeBaseStructure.TIM_Prescaler = 1440;	//TIM4�ǵ�Ƶ��	//�˴��ǳ���֣�Ӧ�ú�ϵͳ��ʼ��ʱ��ı�Ƶ�����й�
  	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
  	TIM_TimeBaseStructure.TIM_Period = 1000;		//50hz  20msһ������   20usһ����λ
  	TIM_TimeBaseStructure.TIM_ClockDivision = 0;   
  	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_Pulse = MOTOR_POS_T_RST;			//20-70     50HzƵ��  50:1ms 5%   100:2ms 10%
	TIM_OC3Init(TIM4, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);	
	TIM_ARRPreloadConfig(TIM4, ENABLE);	
	TIM_Cmd(TIM4, ENABLE);
}
#endif

/*******************************************************************************
* Function Name  : USART_Configuration
* Description    : Configures USART
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_USART_H
void USART_Configuration(void)
{
	USART_InitTypeDef USART_InitStructure;

	USART_InitStructure.USART_BaudRate = 9600;				 			//9600������
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;			//����λΪ8λ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;				//ֹͣλΪ1
	USART_InitStructure.USART_Parity = USART_Parity_No;					//û����żУ��λ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; 	//Ӳ��������ʧ�� ???
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;		//����ʹ�ܽ���ʹ��

	USART_Init(USART1, &USART_InitStructure);				//��ʼ��USART1
//	USART_Init(USART2, &USART_InitStructure);				//��ʼ��USART2
//	USART_Init(USART3, &USART_InitStructure);				//��ʼ��USART3
//	USART_Init(UART4, &USART_InitStructure);				//��ʼ��USART1
//	USART_Init(UART5, &USART_InitStructure);				//��ʼ��USART1

// Enable USART Receive and Transmit interrupts
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);			//���������ж�
//	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);			//���������ж�
//	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);			//���������ж�
//	USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);			//���������ж�
//	USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);			//���������ж�
  
// Enable the USART
	USART_Cmd(USART1, ENABLE);
//	USART_Cmd(USART2, ENABLE);		//485
//	USART_Cmd(USART3, ENABLE);		//GPS
//	USART_Cmd(UART4, ENABLE);		//�������
//	USART_Cmd(UART5, ENABLE);		//��λ��ͨ�ţ�������Ƶ��������
}
#endif

/*******************************************************************************
* Function Name  : WDG_Configuration
* Description    : Configures WDG
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef __STM32F10x_WWDG_H
void WDG_Configuration(void)                //���Ź���ʼ��
{
/*	
	WWDG_SetPrescaler(WWDG_Prescaler_8);	//ʱ��8��Ƶ4ms (PCLK1/4096)/8 = 244 Hz (~4 ms)
	WWDG_SetWindowValue(65);				//��������ֵ
	WWDG_Enable(127);						//����������������ι��ʱ��
	//	WWDG timeout = ~4 ms * 64 = 262 ms
	WWDG_ClearFlag();						//�����־λ
	WWDG_EnableIT();						//�����ж�
*/
//�������Ź���ʼ��
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);	//�����Ĵ�����д
	IWDG_SetPrescaler(IWDG_Prescaler_32);			//40Kʱ��32��Ƶ ,��ʼֵΪ0xfff���3276ms
	IWDG_SetReload(2047);							//��������ֵ��Ϊ����һ�룬1600ms
	IWDG_ReloadCounter();							//����������
	IWDG_Enable();									//�������Ź�
}
#endif


/******************* (C) COPYRIGHT 2008 CY *****END OF FILE****/
