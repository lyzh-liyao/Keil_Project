/******************** (C) COPYRIGHT 2009 Chen Yao ******************************
* File Name          : Temperature18b20.h
* Author             : Chen Yao
* Version            : V1.0
* Date               : 03/05/2014
* Description        : This file contains the headers of Temperature18b20.c
********************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __TEMPERATURE_H
#define __TEMPERATURE_H

#include "stm32f10x.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern u16 temperature[2];

/* Private function prototypes -----------------------------------------------*/
extern void GetTemperature(void);

#endif
