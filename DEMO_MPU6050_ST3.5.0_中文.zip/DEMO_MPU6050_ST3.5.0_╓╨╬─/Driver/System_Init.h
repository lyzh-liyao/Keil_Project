extern void system_init(void);
