#define  True  1
#define  False 0
#define  TRUE  1
#define  FALSE 0
#define   uchar unsigned char
#define   uint unsigned int
typedef unsigned char       bool;
typedef unsigned char       u8;
typedef unsigned short      u16;
